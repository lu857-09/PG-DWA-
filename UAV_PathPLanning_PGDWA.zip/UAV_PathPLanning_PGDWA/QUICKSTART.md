# 快速开始指南

## 5分钟快速上手

### 1. 安装和设置

```matlab
% 在MATLAB中切换到项目目录
cd /path/to/UAV_PathPlanning_PGDWA

% 添加所有子目录到路径
addpath(genpath(pwd))
```

### 2. 运行第一个示例

```matlab
% 运行基础演示
demo_basic

% 或者直接运行主程序
main
```

### 3. 基本使用流程

```matlab
%% 步骤1: 创建配置
config = SystemConfig.defaultConfig();
config.mapSize = [100, 100, 50];
config.maxSpeed = 5.0;

%% 步骤2: 创建环境
env = Environment(config.mapSize);
env.generateRandomObstacles(15, 10, 5);

%% 步骤3: 初始化规划器
pheromoneManager = PheromoneManager(config, env);
astar = AStarPlanner(config, env, pheromoneManager);
dwa = DWAController(config);

%% 步骤4: 设置无人机状态
droneState = struct(...
    'position', [10, 10, 5], ...
    'velocity', [0, 0, 0], ...
    'goal', [90, 90, 45], ...
    'energy', 1000);

%% 步骤5: 创建可视化
visualizer = Visualizer(config);
visualizer.initializeFigures();
visualizer.plotEnvironment(env, droneState.position, droneState.goal);

%% 步骤6: 运行仿真
simulator = Simulator(config, env, astar, dwa, visualizer, pheromoneManager);
simulator.droneState = droneState;
simulator.run();
```

## 常用配置示例

### 快速仿真（降低计算量）

```matlab
config = SystemConfig();
config.mapSize = [50, 50, 30];      % 较小地图
config.gridSize = 3.0;              % 较大栅格
config.maxSpeed = 3.0;              % 降低速度
config.updateInterval = 0.1;        % 降低更新频率
```

### 高精度仿真

```matlab
config = SystemConfig();
config.mapSize = [200, 200, 80];    % 大地图
config.gridSize = 1.0;              % 小栅格
config.maxSpeed = 8.0;              % 高速度
config.updateInterval = 0.05;       % 高更新频率
```

### 禁用动态障碍物

```matlab
config.enableDynamicObstacles = false;
```

## 常见任务

### 保存仿真结果

```matlab
% 运行仿真后
state = simulator.getState();
FileIOUtils.saveSimulationState('my_simulation.mat', state);
```

### 加载之前的仿真

```matlab
state = FileIOUtils.loadSimulationState('my_simulation.mat');
% 恢复环境和状态
env = state.environment;
droneState = state.droneState;
```

### 自定义环境

```matlab
env = Environment([100, 100, 50]);

% 手动添加障碍物
env.obstacles.buildings = [
    20, 20, 15, 10, 25;  % [x, y, width, depth, height]
    60, 40, 20, 20, 30
];

env.obstacles.dynamic = [
    50, 50, 20, 5  % [x, y, z, radius]
];
```

### 导出路径数据

```matlab
% 获取路径历史
pathHistory = simulator.pathHistory;

% 导出为CSV
FileIOUtils.exportPath('flight_path.csv', pathHistory, 'csv');
```

## 键盘控制

运行仿真时可用的键盘快捷键：

- **空格键** - 暂停/继续仿真
- **Q键** - 退出仿真
- **1/2/3** - 选择动态障碍物（需启用动态障碍物）
- **方向键** - 移动选中的障碍物

## 可视化窗口

系统会创建多个可视化窗口：

1. **飞行轨迹图** - 实时显示无人机位置和轨迹
2. **路径规划图** - 显示A*规划的全局路径
3. **信息素分布图** - 显示信息素空间分布（可选）

## 故障排除

### 问题：路径规划失败

```matlab
% 检查起点和终点是否有效
env.checkCollision(startPos)  % 应返回false
env.checkCollision(goalPos)   % 应返回false

% 减小障碍物数量或增大地图
env.generateRandomObstacles(5, 5, 2);
```

### 问题：仿真运行缓慢

```matlab
% 增大栅格尺寸
config.gridSize = 3.0;  % 默认2.0

% 降低可视化频率
config.updateInterval = 0.1;  % 默认0.05

% 关闭部分可视化
config.enableVisualization = false;
```

### 问题：无人机卡住不动

```matlab
% 检查DWA参数
config.maxSpeed = 5.0;      % 确保速度足够
config.maxAccel = 2.0;      % 确保加速度足够
config.obstacleMargin = 3.0; % 减小安全裕度
```

## 进阶使用

### 自定义规划算法

```matlab
% 创建自定义A*启发函数
classdef MyAStarPlanner < AStarPlanner
    methods
        function h = heuristic(obj, grid1, grid2)
            % 你的自定义启发函数
            h = norm(grid1 - grid2) * 1.5;
        end
    end
end
```

### 添加传感器噪声

```matlab
% 在Simulator.run()中添加
noiseLevel = 0.1;
noisyPos = droneState.position + randn(1,3) * noiseLevel;
```

### 多无人机仿真

```matlab
% 创建多个无人机状态
drone1 = struct('position', [10,10,5], 'velocity', [0,0,0], ...);
drone2 = struct('position', [20,20,5], 'velocity', [0,0,0], ...);

% 为每个无人机创建独立的规划器
% （需要扩展Simulator类以支持多无人机）
```

## 性能优化建议

1. **大地图仿真：** 增大gridSize至3.0-5.0
2. **实时性要求：** 降低updateInterval至0.1-0.2
3. **精确规划：** 减小gridSize至1.0-1.5
4. **快速测试：** 使用小地图（50×50×30）

## 下一步

- 📖 阅读完整文档：[README.md](README.md)
- 🔄 了解迁移：[MIGRATION_GUIDE.md](MIGRATION_GUIDE.md)
- 🏗️ 查看结构：[PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md)
- 💻 查看示例：`examples/` 目录

## 获取帮助

- 查看代码注释
- 查看函数文档字符串（`help 函数名`）
- 在GitHub提交Issue

---

祝你使用愉快！ 🚁✨
