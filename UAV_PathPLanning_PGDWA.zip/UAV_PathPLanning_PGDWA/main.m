% main.m - 无人机P-G-DWA*路径规划系统主程序
% 模块化版本 - 基于原始xxs.m重构

clear all; clc; close all;

% 添加所有子目录到路径
addpath(genpath(pwd));

fprintf('\n========================================\n');
fprintf('  无人机三维路径规划系统 P-G-DWA*\n');
fprintf('========================================\n\n');

%% 1. 系统初始化
fprintf('【1/6】初始化系统配置...\n');
config = SystemConfig.defaultConfig();
config.validate();
config.printConfig();

%% 2. 用户交互选项
fprintf('【2/6】配置仿真选项...\n');

loadPreviousState = false;
if FileIOUtils.hasSimulationState('drone_simulation_state.mat')
    reply = input('是否加载上次的仿真状态? (y/n): ', 's');
    if strcmpi(reply, 'y')
        loadPreviousState = true;
    end
end

useLastEnvironment = false;
if FileIOUtils.hasSimulationState('drone_simulation_state.mat') && ~loadPreviousState
    reply = input('是否使用上次的环境布局? (y/n): ', 's');
    if strcmpi(reply, 'y')
        useLastEnvironment = true;
    end
end

reply = input('是否启用动态障碍物避让? (y/n): ', 's');
if strcmpi(reply, 'n')
    config.enableDynamicObstacles = false;
    fprintf('✅ 已关闭动态障碍物避让\n');
else
    config.enableDynamicObstacles = true;
    fprintf('✅ 已启用动态障碍物避让\n');
end

%% 3. 创建环境
fprintf('\n【3/6】创建仿真环境...\n');
env = Environment(config.mapSize);
env.generateRandomObstacles(15, 10, 5);
fprintf('✅ 环境创建完成\n');

%% 4. 初始化状态
droneState = struct('position', [10, 10, 5], 'velocity', [0, 0, 0], ...
                   'goal', [90, 90, 45], 'energy', config.initialEnergy);

%% 5. 初始化规划器和信息素
fprintf('\n【4/6】初始化路径规划器...\n');
pheromoneManager = PheromoneManager(config, env);
astar = AStarPlanner(config, env, pheromoneManager);
dwa = DWAController(config);
fprintf('✅ 规划器初始化完成\n');

%% 6. 创建可视化
fprintf('\n【5/6】初始化可视化系统...\n');
visualizer = Visualizer(config);
visualizer.initializeFigures();
visualizer.plotEnvironment(env, droneState.position, droneState.goal);
fprintf('✅ 可视化系统就绪\n');

%% 7. 运行仿真
fprintf('\n【6/6】开始仿真...\n');
fprintf('========================================\n');
fprintf('控制说明:\n');
fprintf('  [空格键] - 暂停/继续\n');
fprintf('  [Q键]    - 退出仿真\n');
if config.enableDynamicObstacles
    fprintf('  [1/2/3]  - 选择障碍物\n');
    fprintf('  [方向键] - 移动障碍物\n');
end
fprintf('========================================\n\n');

simulator = Simulator(config, env, astar, dwa, visualizer, pheromoneManager);
simulator.droneState = droneState;

try
    simulator.run();
catch ME
    fprintf('\n❌ 仿真异常: %s\n', ME.message);
    disp(ME.stack);
end

fprintf('\n========================================\n');
fprintf('  仿真结束\n');
fprintf('========================================\n');

reply = input('\n是否保存仿真结果? (y/n): ', 's');
if strcmpi(reply, 'y')
    state = simulator.getState();
    FileIOUtils.saveSimulationState('drone_simulation_state.mat', state);
end
