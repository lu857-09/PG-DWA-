# UAV Path Planning based on P-G-DWA* Algorithm

[![MATLAB](https://img.shields.io/badge/MATLAB-R2020a+-blue.svg)](https://www.mathworks.com/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

## 📖 项目简介

本项目实现了基于**P-G-DWA*** (Pheromone-Global-DWA*) 算法的无人机三维路径规划系统。该算法创新性地结合了：

- **A*** 全局路径规划
- **DWA** (Dynamic Window Approach) 局部动态避障
- **信息素机制** 智能路径优化

系统支持复杂三维环境下的实时避障、动态重规划和能量管理。

## ✨ 主要特性

- ✅ 三维环境建模（建筑物、树木、动态障碍物）
- ✅ A*全局路径规划
- ✅ DWA局部实时避障
- ✅ 信息素引导和蒸发机制
- ✅ 动态路径重规划
- ✅ 实时可视化显示
- ✅ 能量消耗模拟
- ✅ 碰撞检测系统
- ✅ 统计数据分析

## 📁 项目结构

```
UAV_PathPlanning_PGDWA/
├── README.md                          # 项目说明文档
├── LICENSE                            # 开源协议
├── main.m                             # 主程序入口
├── config/
│   └── SystemConfig.m                 # 系统配置类
├── core/
│   └── Simulator.m                    # 仿真主控制器
├── planning/
│   ├── PGDWAStar.m                    # P-G-DWA*规划器
│   ├── AStarPlanner.m                 # A*算法
│   └── DWAController.m                # DWA控制器
├── pheromone/
│   └── PheromoneManager.m             # 信息素管理器
├── environment/
│   └── Environment.m                  # 环境类
├── visualization/
│   └── Visualizer.m                   # 可视化类
└── examples/
    └── demo_basic.m                   # 基础示例
```

## 🚀 快速开始

### 环境要求

- MATLAB R2020a 或更高版本
- 无需额外工具箱

### 安装步骤

1. 克隆或下载本项目
2. 在MATLAB中打开项目文件夹

### 运行示例

#### 方法1: 运行主程序
```matlab
main
```

#### 方法2: 运行基础示例
```matlab
cd examples
demo_basic
```

#### 方法3: 自定义代码
```matlab
addpath(genpath('.'));
config = SystemConfig.getDefaultConfig();
env = Environment([100, 100, 50], 2.0);
env.generateRandomObstacles(8, 15);
start = [10, 10, 5];
goal = [85, 85, 30];
sim = Simulator(config);
sim.initialize(start, goal);
sim.run(1000);
```

## 📊 算法原理

### P-G-DWA* 算法框架

1. **全局规划 (A*)**: 基于环境地图规划全局路径
2. **局部控制 (DWA)**: 实时计算最优速度，避障
3. **信息素机制**: 路径信息素沉积与蒸发
4. **动态重规划**: 环境变化时重新规划路径

### 核心公式

**DWA评估函数:**
```
G(v) = α·heading(v) + β·clearance(v) + γ·velocity(v) + δ·pheromone(v)
```

**信息素更新:**
```
τ(t+1) = (1-ρ)·τ(t) + Δτ
```

## 🎯 配置说明

主要配置参数在 `config/SystemConfig.m` 中定义：

| 参数 | 默认值 | 说明 |
|------|--------|------|
| MAP_SIZE | [100,100,50] | 地图尺寸(米) |
| MAX_VELOCITY | 5.0 | 最大速度(m/s) |
| PHEROMONE_WEIGHT | 0.5 | 信息素权重 |
| EVAPORATION_RATE | 0.05 | 蒸发率 |

## 📝 使用示例

详见 `examples/demo_basic.m` 中的三个完整示例。

## 📄 许可证

MIT License - 详见 [LICENSE](LICENSE)

## 📧 联系方式

如有问题请提交Issue或联系作者。

---

**⭐ 如果这个项目对您有帮助，请给个Star！**
