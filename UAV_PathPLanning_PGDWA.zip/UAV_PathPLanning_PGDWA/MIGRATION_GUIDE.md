# 迁移指南 - 从单文件到模块化结构

本指南帮助你理解如何从原始的`xxs.m`单文件代码迁移到模块化的项目结构。

## 原始代码结构分析

原始`xxs.m`文件（约7620行）包含：
- 全局变量定义（行1-125）
- 环境生成和障碍物管理（行162-500）
- A*路径规划算法（行500-2000）
- DWA避障控制（行2000-3500）
- 信息素管理系统（行3500-5000）
- 可视化代码（行5000-6500）
- 主仿真循环（行6500-7620）

## 模块化重构映射

### 1. 全局变量 → 类属性

**原始代码：**
```matlab
global globalObstacles;
global droneState;
global pheromoneManager;
```

**重构后：**
```matlab
% 在各自的类中作为属性
classdef Environment < handle
    properties
        obstacles
    end
end

classdef Simulator < handle
    properties
        droneState
        pheromoneManager
    end
end
```

### 2. 环境管理功能

**原始位置：** `xxs.m` 行162-500

**迁移到：**
- `environment/Environment.m` - 环境类
- `environment/ObstacleManager.m` - 障碍物管理
- `environment/CollisionDetector.m` - 碰撞检测

**主要函数映射：**
```matlab
% 原始函数 → 新位置
generateStaticObstacles()     → Environment.generateRandomObstacles()
checkCollision()              → Environment.checkCollision()
updateDynamicObstacles()      → ObstacleManager.updateDynamic()
```

### 3. A*路径规划

**原始位置：** `xxs.m` 行500-2000

**迁移到：** `planning/AStarPlanner.m`

**主要函数映射：**
```matlab
% 原始函数 → 新位置
aStar3D()                    → AStarPlanner.findPath()
heuristicCost()              → AStarPlanner.heuristic()
reconstructPath()            → AStarPlanner.reconstructPath()
getNeighbors()               → AStarPlanner.getNeighbors()
```

### 4. DWA控制器

**原始位置：** `xxs.m` 行2000-3500

**迁移到：** `planning/DWAController.m`

**主要函数映射：**
```matlab
% 原始函数 → 新位置
dynamicWindowApproach()      → DWAController.computeVelocity()
predictTrajectory()          → DWAController.predictTrajectory()
evaluateTrajectory()         → DWAController.goalCost() + obstacleCost()
dynamicWindow()              → DWAController.computeDynamicWindow()
```

### 5. 信息素系统

**原始位置：** `xxs.m` 行3500-5000

**迁移到：**
- `pheromone/PheromoneManager.m` - 信息素管理器
- `pheromone/PheromoneAnalyzer.m` - 分析工具
- `pheromone/PheromoneVisualizer.m` - 可视化

**主要函数映射：**
```matlab
% 原始函数 → 新位置
initializePheromoneMatrix()      → PheromoneManager.__init__()
depositPheromone()               → PheromoneManager.depositPathPheromone()
evaporatePheromone()             → PheromoneManager.evaporate()
updateObstaclePheromones()       → PheromoneManager.depositAvoidancePheromone()
```

### 6. 可视化系统

**原始位置：** `xxs.m` 行5000-6500

**迁移到：**
- `visualization/Visualizer.m` - 主可视化类
- `visualization/FigureManager.m` - 窗口管理
- `visualization/PlotUtils.m` - 绘图工具

**主要函数映射：**
```matlab
% 原始函数 → 新位置
initializeFigures()          → Visualizer.initializeFigures()
plotEnvironment()            → Visualizer.plotEnvironment()
updateDronePlot()            → Visualizer.updatePlot()
plotPheromone()              → PheromoneVisualizer.plot3D()
```

### 7. 主仿真循环

**原始位置：** `xxs.m` 行6500-7620

**迁移到：**
- `core/Simulator.m` - 仿真控制器
- `core/DroneController.m` - 无人机控制
- `core/StateManager.m` - 状态管理

**主要逻辑映射：**
```matlab
% 原始代码 → 新位置
while simulationRunning         → Simulator.run()
  updateDroneState()            → DroneController.updateState()
  checkCollisions()             → CollisionDetector.check()
  updatePheromones()            → PheromoneManager.evaporate()
  updateVisuals()               → Visualizer.updatePlot()
end
```

## 迁移步骤

### 第一步：理解模块化架构

1. 阅读 `README.md` 了解项目结构
2. 查看 `config/SystemConfig.m` 了解参数配置
3. 运行 `examples/demo_basic.m` 熟悉新的使用方式

### 第二步：配置参数迁移

如果你在原始代码中修改了参数，在 `SystemConfig.m` 中找到对应的属性：

```matlab
% 原始代码
maxSpeed = 5.0;
gridSize = 2.0;

% 新代码
config = SystemConfig();
config.maxSpeed = 5.0;
config.gridSize = 2.0;
```

### 第三步：自定义功能迁移

如果你扩展了原始代码，按照以下方式迁移：

1. **新增算法**
   - 在 `planning/` 目录创建新的类文件
   - 继承适当的基类
   - 实现必要的接口方法

2. **自定义环境**
   - 修改 `Environment.generateRandomObstacles()`
   - 或创建专门的环境配置文件

3. **特殊可视化**
   - 扩展 `Visualizer` 类
   - 或创建独立的可视化模块

### 第四步：从原始代码提取逻辑

如果需要从原始 `xxs.m` 提取特定功能：

```matlab
% 1. 找到原始代码中的函数
% 2. 确定应该属于哪个模块
% 3. 在对应类中添加方法

% 示例：提取自定义的碰撞检测逻辑
% 原始位置：xxs.m 行XXX
function isCollision = myCustomCollisionCheck(pos, obstacles)
    % ... 你的代码 ...
end

% 迁移后：environment/CollisionDetector.m
classdef CollisionDetector < handle
    methods
        function isCollision = customCheck(obj, pos, obstacles)
            % ... 你的代码 ...
        end
    end
end
```

## 常见迁移场景

### 场景1：保留原始环境配置

```matlab
% 如果你有特定的环境布局
% 原始：在xxs.m中硬编码

% 新方法：创建自定义环境函数
function env = createMyEnvironment(mapSize)
    env = Environment(mapSize);
    % 添加特定障碍物
    env.obstacles.buildings = [...]; % 你的数据
    env.obstacles.trees = [...];
end
```

### 场景2：使用自定义的信息素规则

```matlab
% 原始：直接修改信息素更新代码

% 新方法：扩展PheromoneManager
classdef MyPheromoneManager < PheromoneManager
    methods
        function depositPathPheromone(obj, position, amount)
            % 你的自定义逻辑
            % 可以调用父类方法
            depositPathPheromone@PheromoneManager(obj, position, amount);
        end
    end
end
```

### 场景3：集成已保存的仿真数据

```matlab
% 如果你有用原始代码保存的状态

% 加载原始数据
load('old_simulation_state.mat');

% 转换为新格式
config = SystemConfig();
env = Environment(mapSize);
env.obstacles = obstacles; % 从旧数据

% 继续仿真...
```

## 优势对比

### 原始单文件代码
**优点：**
- 所有代码在一个文件中，便于查找
- 无需管理多个文件

**缺点：**
- 7620行代码难以维护
- 全局变量容易冲突
- 代码复用困难
- 难以单元测试
- 团队协作困难

### 模块化代码
**优点：**
- ✅ 清晰的模块划分
- ✅ 高度可复用
- ✅ 易于维护和扩展
- ✅ 支持单元测试
- ✅ 便于版本控制
- ✅ 适合团队开发
- ✅ 符合MATLAB最佳实践

**缺点：**
- 需要理解项目结构
- 文件数量增加

## 完整迁移示例

### 原始代码片段
```matlab
% xxs.m (简化版本)
clear all; clc;
global globalObstacles;
global droneState;

% 初始化
mapSize = [100, 100, 50];
droneState = struct('pos', [10,10,5], 'vel', [0,0,0]);

% 生成环境
globalObstacles = generateObstacles();

% A*规划
path = aStar3D(droneState.pos, goal);

% 主循环
while running
    % DWA控制
    vel = dwa(droneState, obstacles);
    droneState.pos = droneState.pos + vel * dt;
    
    % 更新可视化
    updatePlot(droneState);
end
```

### 迁移后代码
```matlab
% main.m
addpath(genpath(pwd));

% 配置
config = SystemConfig();
config.mapSize = [100, 100, 50];

% 创建对象
env = Environment(config.mapSize);
env.generateRandomObstacles(15, 10, 5);

pheromoneManager = PheromoneManager(config, env);
astar = AStarPlanner(config, env, pheromoneManager);
dwa = DWAController(config);
visualizer = Visualizer(config);

% 初始化状态
droneState = struct('position', [10,10,5], 'velocity', [0,0,0], ...
                   'goal', [90,90,45], 'energy', 1000);

% 运行仿真
simulator = Simulator(config, env, astar, dwa, visualizer, pheromoneManager);
simulator.droneState = droneState;
simulator.run();
```

## 获取帮助

- 📖 阅读代码注释和文档字符串
- 💡 查看 `examples/` 目录中的示例
- 🐛 在GitHub Issues报告问题
- 📧 联系项目维护者

## 总结

模块化重构使代码：
1. 更易理解和维护
2. 更便于扩展新功能
3. 更适合专业开发
4. 更容易集成到其他项目

建议逐步迁移，先理解新架构，再逐步移植自定义功能。
